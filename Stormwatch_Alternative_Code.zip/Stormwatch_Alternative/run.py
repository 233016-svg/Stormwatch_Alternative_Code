import argparse
import csv
import json
from pathlib import Path
from statistics import mean
from engine import Harbour, MODES
from master import external_master


def main():
    p = argparse.ArgumentParser(description="Stormwatch Harbour home-berth study")
    p.add_argument("--seed", type=int, default=11)
    p.add_argument("--mode", choices=MODES, default="memory")
    p.add_argument("--evaluate", action="store_true")
    p.add_argument("--test", action="store_true")
    p.add_argument("--adapter", nargs=argparse.REMAINDER)
    args = p.parse_args()
    folder = Path(__file__).parent / "results"
    folder.mkdir(exist_ok=True)
    if args.test:
        from tests import run_checks
        result = run_checks()
        (folder / "tests.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(json.dumps(result, indent=2))
        return
    if args.evaluate:
        records = [Harbour(seed, mode).run() for mode in ("fixed", "memory", "fixture") for seed in range(11, 16)]
        (folder / "runs.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
        with (folder / "runs.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=records[0].keys())
            writer.writeheader(); writer.writerows(records)
        summaries = []
        for seeds in ((11, 12, 13), (11, 12, 13, 14, 15)):
            for mode in ("fixed", "memory", "fixture"):
                group = [r for r in records if r["mode"] == mode and r["seed"] in seeds]
                summaries.append({"seeds": list(seeds), "mode": mode,
                                  **{k: mean(r[k] for r in group) for k in ("delivered", "knockouts", "invalid", "fallback", "calls", "holds")}})
        (folder / "means.json").write_text(json.dumps(summaries, indent=2), encoding="utf-8")
        simulation = Harbour(11, "fixture"); simulation.run()
        (folder / "fixture_decisions_seed11.json").write_text(json.dumps(simulation.trace, indent=2), encoding="utf-8")
        print(json.dumps(summaries, indent=2))
    else:
        if args.mode == "live" and not args.adapter:
            p.error("live mode needs --adapter EXECUTABLE ARGUMENTS")
        backend = (lambda report: external_master(args.adapter, report)) if args.adapter else None
        sim = Harbour(args.seed, args.mode, backend)
        print(json.dumps(sim.run(), indent=2))
        (folder / f"{args.mode}_{args.seed}_decisions.json").write_text(json.dumps(sim.trace, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
