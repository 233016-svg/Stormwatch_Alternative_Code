"""Home-berth assignment with warning memory and shortest-path routing."""
from collections import deque
from dataclasses import dataclass
import random
import subprocess
from master import check_action, offline_master

DOCKS = ((2, 0), (8, 0), (14, 0), (20, 0))
STORE = (0, 15)
DANGEROUS = {0, 3}
MODES = ("fixed", "memory", "fixture", "live")


def events(seed):
    rng = random.Random(seed)
    arrivals, t = [], 0
    while t < 600:
        t += rng.randint(6, 10)
        if t < 600:
            arrivals.append(t)
    storms = tuple(rng.randint(a, b) for a, b in ((100, 170), (280, 350), (460, 530)))
    return tuple(arrivals), storms


def next_step(start, goal, forbidden=()):
    """BFS on a 24 by 16 map; berth cells cannot be transit corridors."""
    if start == goal:
        return start
    blocked = set(forbidden)
    frontier = deque([start])
    parent = {start: None}
    while frontier:
        cell = frontier.popleft()
        x, y = cell
        for nxt in ((x, y - 1), (x + 1, y), (x, y + 1), (x - 1, y)):
            nx, ny = nxt
            if not (0 <= nx < 24 and 0 <= ny < 16):
                continue
            if nxt in parent or nxt in blocked or (ny == 0 and nxt != goal):
                continue
            parent[nxt] = cell
            if nxt == goal:
                while parent[nxt] != start:
                    nxt = parent[nxt]
                return nxt
            frontier.append(nxt)
    return start


@dataclass
class Vessel:
    number: int
    left: int = 8
    hold_until: int = 0


@dataclass
class Porter:
    home: int
    position: tuple = STORE
    loaded: bool = False
    destination: int | None = None
    unavailable_until: int = 0


class Harbour:
    def __init__(self, seed, mode, master=None):
        if mode not in MODES:
            raise ValueError("unknown mode")
        if mode == "live" and master is None:
            raise ValueError("live mode requires a real-model adapter")
        self.seed, self.mode = seed, mode
        self.arrivals, self.storms = events(seed)
        self.master = master or offline_master
        self.workers = [Porter(i % 4) for i in range(10)]
        self.docks = [None] * 4
        self.waiting, self.ships = [], []
        self.memory_end = -1
        self.metrics = dict(delivered=0, knockouts=0, lost=0,
                            invalid=0, fallback=0, calls=0, holds=0)
        self.trace = []

    def run(self):
        for tick in range(600):
            storm = any(s <= tick < s + 15 for s in self.storms)
            warning = any(s - 5 <= tick < s for s in self.storms)
            if tick in self.arrivals:
                ship = Vessel(len(self.ships) + 1)
                self.ships.append(ship)
                self.waiting.append(ship)
            if self.mode != "fixed" and warning:
                self.memory_end = next(s + 15 for s in self.storms if s - 5 <= tick < s)
            blocked_docks = DANGEROUS if self.mode != "fixed" and tick < self.memory_end else set()
            forbidden = {DOCKS[i] for i in blocked_docks}
            if self.mode in ("fixture", "live") and (tick % 12 == 0 or tick in [s - 5 for s in self.storms]):
                report = {"tick": tick, "warning": warning, "storm": storm,
                          "berths": [{"berth": f"B{i+1}", "ship": s.number if s else None,
                                      "safe": not (storm and i in DANGEROUS)} for i, s in enumerate(self.docks)],
                          "waiting": [s.number for s in self.waiting]}
                self.metrics["calls"] += 1
                try:
                    raw = self.master(report)
                except (OSError, subprocess.SubprocessError):
                    raw = ""
                action = check_action(raw, report["waiting"])
                if action is None:
                    self.metrics["invalid"] += 1
                    self.metrics["fallback"] += 1
                elif action["name"] == "hold_ship":
                    ship_id = action["arguments"]["ship_id"]
                    next(s for s in self.waiting if s.number == ship_id).hold_until = tick + 6
                    self.metrics["holds"] += 1
                # warn_storm broadcasts current sensor state, never fabricates weather.
                self.trace.append({"report": report, "output": raw,
                                   "accepted": action, "fallback": action is None})
            for berth in range(4):
                if self.docks[berth] is None and not (storm and berth in DANGEROUS):
                    ship = next((s for s in self.waiting if s.hold_until <= tick), None)
                    if ship is not None:
                        self.waiting.remove(ship)
                        self.docks[berth] = ship
            for w in self.workers:
                if storm and w.position in (DOCKS[0], DOCKS[3]) and tick >= w.unavailable_until:
                    self.metrics["knockouts"] += 1
                    self.metrics["lost"] += int(w.loaded)
                    w.position, w.loaded, w.destination = STORE, False, None
                    w.unavailable_until = tick + 12
            reservations = [0] * 4
            for w in self.workers:
                b = w.destination
                if b is not None:
                    if b in blocked_docks or self.docks[b] is None or self.docks[b].left == 0:
                        w.destination = None
                    else:
                        reservations[b] += 1
            for w in self.workers:
                if tick < w.unavailable_until:
                    continue
                if w.loaded:
                    if w.position == STORE:
                        self.metrics["delivered"] += 1
                        w.loaded = False
                    else:
                        w.position = next_step(w.position, STORE, forbidden)
                    continue
                if w.destination is None:
                    choices = [w.home] if w.home not in blocked_docks else [1, 2]
                    choices = [b for b in choices if self.docks[b] and self.docks[b].left > reservations[b]]
                    if choices:
                        b = min(choices, key=lambda i: (abs(w.position[0]-DOCKS[i][0]) + abs(w.position[1]-DOCKS[i][1]), i))
                        w.destination = b
                        reservations[b] += 1
                b = w.destination
                if b is not None:
                    if w.position == DOCKS[b]:
                        assert self.docks[b] is not None and self.docks[b].left > 0
                        self.docks[b].left -= 1
                        w.loaded, w.destination = True, None
                        reservations[b] -= 1
                    else:
                        w.position = next_step(w.position, DOCKS[b], forbidden)
                elif w.position in forbidden:
                    w.position = next_step(w.position, STORE, forbidden)
            for i, ship in enumerate(self.docks):
                if ship and ship.left == 0:
                    self.docks[i] = None
            assert all(0 <= w.position[0] < 24 and 0 <= w.position[1] < 16 for w in self.workers)
            assert self.metrics["delivered"] + self.metrics["lost"] + sum(w.loaded for w in self.workers) + sum(s.left for s in self.ships) == len(self.ships) * 8
            assert all(s.left >= 0 for s in self.ships)
        return {"seed": self.seed, "mode": self.mode, **self.metrics,
                "ships_arrived": len(self.ships), "storm_starts": list(self.storms)}
