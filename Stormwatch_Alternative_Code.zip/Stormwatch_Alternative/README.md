# Stormwatch Harbour home-berth study

An independently implemented worked version of CGD-460 Assignment 2.

## Quick start

Requires Python 3.10+ and no third-party packages.

```sh
python run.py --seed 11 --mode fixed
python run.py --seed 11 --mode memory
python run.py --seed 11 --mode fixture
python run.py --evaluate
python run.py --test
```

`fixed` is the baseline, `memory` is the model-based worker policy, and `fixture` is the model-based worker policy with a scripted Harbour Master. `live` requires your own real-model adapter. Evaluation uses seeds 11-15, with 11-13 as the main comparison because those are explicitly requested in Tasks 2 and 3. JSON and CSV files are written to `results/`.

## Design

The map has 24 columns and 16 rows, with zero-based coordinates measured east and south from the north-west. B1=(2,0), B2=(8,0), B3=(14,0), B4=(20,0); warehouse=(0,15). The ten workers have fixed home berths: worker i belongs to berth i modulo 4, giving allocations of 3,3,2,2. A cargo reservation prevents more workers being dispatched than the remaining cargo. Workers can share cells.

The baseline works only at its home berth, ignoring warnings. The memory policy stores the end of the upcoming storm; for the five warning ticks and fifteen storm ticks, B1/B4 assignments are cancelled. Affected workers can help at the nearest available safe berth (B2 or B3). Workers finish a safe diverted trip before returning to home assignment. If no alternate cargo is available, a worker on an unsafe berth evacuates. Both policies use identical BFS shortest-path movement and reservations. Berth cells on row 0 are destinations, not transit corridors; workers cross horizontally on row 1 or farther south. A blocked start can be exited during evacuation.

At most one worker action occurs per tick: move one orthogonal cell, pick up one unit, or deliver one unit. Warning broadcasts, scheduling and admission are controller bookkeeping. Loaded workers travel to the warehouse and spend a separate tick dropping off cargo. Empty ships depart after their final pickup. No new ship enters B1/B4 during an active storm.

## Explicit assumptions

- Run ticks are 0-599. Every ship brings exactly 8 cargo units, and the waiting queue has unlimited capacity.
- One `random.Random(seed)` generates all events before the run. Arrival intervals are uniformly sampled integers from 6 through 10. One storm start is sampled from each window 100-170, 280-350, and 460-530. Each lasts 15 ticks and has a five-tick advance warning. Windows guarantee no overlap.
- Storm contact at B1 or B4 knocks a worker out, discards carried cargo, returns the worker to the warehouse and prevents work for 12 ticks including the contact tick. This consequence is an assumption because the brief does not specify recovery.
- Tick order: arrival and warning-memory update; Harbour Master if due; ship admission; storm contact; worker scheduling/actions in index order; empty-ship departure; invariant checks.
- Remaining cargo includes ships already in the waiting queue. Every tick checks that initial cargo equals delivered + lost + carried + cargo still on ships, and that positions and cargo counts are valid.

## Harbour Master boundary

The `fixture` mode is an offline test double, **not an LLM**. It is called every 12 ticks and on warning onset. It warns when a warning is present or no ship is waiting; otherwise it holds the newest waiting ship for six ticks. A warning merely broadcasts the true sensor state. The fixture runs over the same memory-based worker controller. If a proposal is invalid, no action is applied and the memory controller continues.

Allowed output shapes:

```json
{"name":"warn_storm","arguments":{}}
```

```json
{"name":"hold_ship","arguments":{"ship_id":3}}
```

Exact key sets, integer type (excluding bool) and membership of the current waiting list are enforced. Duplicate keys, unknown capabilities, extra arguments, malformed JSON and outputs over 4096 characters are rejected. Responses are never passed to `eval` or a shell. The trusted instruction and untrusted report are separate JSON fields. Closing the harbour, releasing cargo and disabling approval are not executable capabilities. A future privileged action must require a separate human approval gate.

`ship_answer(9, [3,5])` returns exactly `Ship 9 is not listed in the report.` Tests include the exact malicious manifest, player message and crew note as report data. These tests exercise the deterministic fixture and boundary; they are not real LLM prompt-injection evaluations.

For a live model, write an adapter that reads one JSON request from stdin (`instruction` plus `report`), calls a model and prints only its action JSON. Keep keys in environment variables and out of source control. Invoke:

```sh
python run.py --seed 11 --mode live --adapter python adapter.py
```

The adapter is not supplied. The subprocess runs without a shell and has a 20-second timeout. Nonzero exits and timeouts count as invalid outputs and fallback uses. Rerun seeds 11-13 and record provider/model/version, settings, prompt and action traces to complete the live evaluation. Offline fixture measurements must not be labelled as LLM measurements.

## Outputs and verification

- `engine.py`: state model, event schedule, agents and BFS.
- `master.py`: validator, offline fixture, adapter interface and grounded ship response.
- `run.py`: CLI, experiments and mean calculations.
- `tests.py`: executable safety, repeatability, scheduling and fallback tests.
- `results/runs.csv` and `runs.json`: complete measured experiments.
- `results/means.json`: three-seed and five-seed arithmetic means.
- `results/tests.json`: named checks with outcomes.
- `results/fixture_decisions_seed11.json`: reports and accepted/rejected proposals.
- `results/comparison.svg`: reproducible cargo and knock-out chart.

The report, simulation and declaration were prepared with AI assistance. Review the code and record your own checks truthfully before submission. No student name, ID or hosted repository URL has been invented. Upload this directory to your own repository and submit its real link. The live-LLM evaluation remains incomplete; the user selected an offline fixture for this version.
